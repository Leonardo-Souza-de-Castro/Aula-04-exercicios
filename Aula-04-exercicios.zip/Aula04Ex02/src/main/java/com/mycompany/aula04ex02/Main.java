/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.aula04ex02;

/**
 *
 * @author uniflcastro
 */
public class Main {
    public static void main(String[] args) {
        System.out.println(Matematica.max3(1,2,3));
        System.out.println(Matematica.impar(false,true,false));
        System.out.println(Matematica.maioria(false,true,false));
        
        
    }
}
